﻿Imports System.Net
Imports System.Text.Json
Imports Microsoft.AspNetCore.Http

Namespace Middleware
    Public Class ErrorHandlerMiddleware
        Private ReadOnly _next As RequestDelegate

        Public Sub New(nextDelegate As RequestDelegate)
            _next = nextDelegate
        End Sub

        Public Async Function Invoke(context As HttpContext) As Task
            Dim excepcionAtrapada As Exception = Nothing

            Try
                Await _next(context)
            Catch ex As Exception
                excepcionAtrapada = ex
            End Try

            If excepcionAtrapada IsNot Nothing Then
                Await HandleExceptionAsync(context, excepcionAtrapada)
            End If
        End Function

        Private Shared Async Function HandleExceptionAsync(context As HttpContext, exception As Exception) As Task
            Dim response = context.Response
            response.ContentType = "application/json"

            Dim mensajeError = exception.Message

            Select Case True
                Case TypeOf exception Is KeyNotFoundException
                    response.StatusCode = CInt(HttpStatusCode.NotFound)

                Case TypeOf exception Is InvalidOperationException
                    response.StatusCode = CInt(HttpStatusCode.Conflict)

                Case Else
                    response.StatusCode = CInt(HttpStatusCode.InternalServerError)
                    mensajeError = "Ocurrió un error inesperado en el servidor."
            End Select

            Dim result = JsonSerializer.Serialize(New With {Key .mensaje = mensajeError})
            Await response.WriteAsync(result)
        End Function
    End Class
End Namespace