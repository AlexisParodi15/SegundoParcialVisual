﻿Imports InventarioAPI.Models
Imports InventarioAPI.Repositories

Namespace Services
    Public Interface ICategoriaService
        Function ObtenerTodas() As List(Of Categoria)
        Function ObtenerPorId(id As Integer) As Categoria
        Sub Registrar(categoria As Categoria)
        Sub Modificar(categoria As Categoria)
        Sub Eliminar(id As Integer)
    End Interface

    Public Class CategoriaService
        Implements ICategoriaService

        Private ReadOnly _repository As ICategoriaRepository

        Public Sub New(repository As ICategoriaRepository)
            _repository = repository
        End Sub

        Public Function ObtenerTodas() As List(Of Categoria) Implements ICategoriaService.ObtenerTodas
            Return _repository.ObtenerTodas()
        End Function

        Public Function ObtenerPorId(id As Integer) As Categoria Implements ICategoriaService.ObtenerPorId
            Dim categoria = _repository.ObtenerPorId(id)
            If categoria Is Nothing Then Throw New KeyNotFoundException("La categoría no existe.")
            Return categoria
        End Function

        Public Sub Registrar(categoria As Categoria) Implements ICategoriaService.Registrar
            If _repository.ExistePorNombre(categoria.Nombre) Then
                Throw New InvalidOperationException("Ya existe una categoría con ese nombre.")
            End If
            _repository.Agregar(categoria)
            _repository.GuardarCambios()
        End Sub

        Public Sub Modificar(categoria As Categoria) Implements ICategoriaService.Modificar
            Dim existente = _repository.ObtenerPorId(categoria.Id)
            If existente Is Nothing Then Throw New KeyNotFoundException("La categoría no existe.")

            If existente.Nombre.ToLower() <> categoria.Nombre.ToLower() AndAlso _repository.ExistePorNombre(categoria.Nombre) Then
                Throw New InvalidOperationException("Ya existe otra categoría con ese nombre.")
            End If

            existente.Nombre = categoria.Nombre
            existente.Descripcion = categoria.Descripcion
            _repository.Actualizar(existente)
            _repository.GuardarCambios()
        End Sub

        Public Sub Eliminar(id As Integer) Implements ICategoriaService.Eliminar
            Dim categoria = _repository.ObtenerConProductos(id)
            If categoria Is Nothing Then Throw New KeyNotFoundException("La categoría no existe.")

            If categoria.Productos IsNot Nothing AndAlso categoria.Productos.Count > 0 Then
                Throw New InvalidOperationException("No se puede eliminar una categoría que tiene productos asociados.")
            End If

            _repository.Eliminar(categoria)
            _repository.GuardarCambios()
        End Sub
    End Class
End Namespace