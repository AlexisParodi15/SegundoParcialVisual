﻿Imports InventarioAPI.Models
Imports InventarioAPI.Repositories

Namespace Services
    Public Interface IProductoService
        Function ObtenerTodos() As List(Of Producto)
        Function ObtenerPorId(id As Integer) As Producto
        Function ObtenerPorCategoria(categoriaId As Integer) As List(Of Producto)
        Sub Registrar(producto As Producto)
        Sub Modificar(producto As Producto)
        Sub Eliminar(id As Integer)
    End Interface

    Public Class ProductoService
        Implements IProductoService

        Private ReadOnly _productoRepo As IProductoRepository
        Private ReadOnly _categoriaRepo As ICategoriaRepository

        Public Sub New(productoRepo As IProductoRepository, categoriaRepo As ICategoriaRepository)
            _productoRepo = productoRepo
            _categoriaRepo = categoriaRepo
        End Sub

        Public Function ObtenerTodos() As List(Of Producto) Implements IProductoService.ObtenerTodos
            Return _productoRepo.ObtenerTodos()
        End Function

        Public Function ObtenerPorId(id As Integer) As Producto Implements IProductoService.ObtenerPorId
            Dim producto = _productoRepo.ObtenerPorId(id)
            If producto Is Nothing Then Throw New KeyNotFoundException("El producto no existe.")
            Return producto
        End Function

        Public Function ObtenerPorCategoria(categoriaId As Integer) As List(Of Producto) Implements IProductoService.ObtenerPorCategoria
            Return _productoRepo.ObtenerPorCategoria(categoriaId)
        End Function

        Public Sub Registrar(producto As Producto) Implements IProductoService.Registrar
            If _productoRepo.ExistePorNombre(producto.Nombre) Then
                Throw New InvalidOperationException("Ya existe un producto con ese nombre.")
            End If

            If _categoriaRepo.ObtenerPorId(producto.CategoriaId) Is Nothing Then
                Throw New InvalidOperationException("La categoría especificada no existe.")
            End If

            If producto.Stock < 0 Then
                Throw New InvalidOperationException("El stock no puede ser negativo.")
            End If

            producto.FechaRegistro = DateTime.Now
            _productoRepo.Agregar(producto)
            _productoRepo.GuardarCambios()
        End Sub

        Public Sub Modificar(producto As Producto) Implements IProductoService.Modificar
            Dim existente = _productoRepo.ObtenerPorId(producto.Id)
            If existente Is Nothing Then Throw New KeyNotFoundException("El producto no existe.")

            If existente.Nombre.ToLower() <> producto.Nombre.ToLower() AndAlso _productoRepo.ExistePorNombre(producto.Nombre) Then
                Throw New InvalidOperationException("Ya existe otro producto con ese nombre.")
            End If

            If _categoriaRepo.ObtenerPorId(producto.CategoriaId) Is Nothing Then
                Throw New InvalidOperationException("La categoría especificada no existe.")
            End If

            If producto.Stock < 0 Then
                Throw New InvalidOperationException("El stock no puede ser negativo.")
            End If

            existente.Nombre = producto.Nombre
            existente.Descripcion = producto.Descripcion
            existente.Precio = producto.Precio
            existente.Stock = producto.Stock
            existente.CategoriaId = producto.CategoriaId

            _productoRepo.Actualizar(existente)
            _productoRepo.GuardarCambios()
        End Sub

        Public Sub Eliminar(id As Integer) Implements IProductoService.Eliminar
            Dim producto = _productoRepo.ObtenerPorId(id)
            If producto Is Nothing Then Throw New KeyNotFoundException("El producto no existe.")

            _productoRepo.Eliminar(producto)
            _productoRepo.GuardarCambios()
        End Sub
    End Class
End Namespace