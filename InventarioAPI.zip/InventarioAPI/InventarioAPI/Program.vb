﻿Imports Microsoft.AspNetCore.Builder
Imports Microsoft.EntityFrameworkCore
Imports Microsoft.Extensions.Configuration
Imports Microsoft.Extensions.DependencyInjection
Imports Microsoft.Extensions.Hosting
Imports InventarioAPI.Data

Module Program
    Sub Main(args As String())
        Dim builder = WebApplication.CreateBuilder(args)

        builder.Services.AddControllers()

        Dim connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
        builder.Services.AddDbContext(Of AppDbContext)(Sub(options)
                                                           options.UseSqlServer(connectionString)
                                                       End Sub)

        builder.Services.AddScoped(Of Repositories.ICategoriaRepository, Repositories.CategoriaRepository)()
        builder.Services.AddScoped(Of Repositories.IProductoRepository, Repositories.ProductoRepository)()

        builder.Services.AddScoped(Of Services.ICategoriaService, Services.CategoriaService)()
        builder.Services.AddScoped(Of Services.IProductoService, Services.ProductoService)()

        builder.Services.AddEndpointsApiExplorer()
        builder.Services.AddSwaggerGen()

        Dim app = builder.Build()

        app.UseMiddleware(Of Middleware.ErrorHandlerMiddleware)()

        If app.Environment.IsDevelopment() Then
            app.UseSwagger()
            app.UseSwaggerUI()
        End If

        app.UseAuthorization()
        app.MapControllers()

        app.Run()
    End Sub
End Module