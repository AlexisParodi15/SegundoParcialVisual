﻿Imports Microsoft.EntityFrameworkCore
Imports InventarioAPI.Data
Imports InventarioAPI.Models

Namespace Repositories
    Public Interface ICategoriaRepository
        Function ObtenerTodas() As List(Of Categoria)
        Function ObtenerPorId(id As Integer) As Categoria
        Function ObtenerConProductos(id As Integer) As Categoria
        Function ExistePorNombre(nombre As String) As Boolean
        Sub Agregar(categoria As Categoria)
        Sub Actualizar(categoria As Categoria)
        Sub Eliminar(categoria As Categoria)
        Function GuardarCambios() As Boolean
    End Interface

    Public Class CategoriaRepository
        Implements ICategoriaRepository

        Private ReadOnly _context As AppDbContext

        Public Sub New(context As AppDbContext)
            _context = context
        End Sub

        Public Function ObtenerTodas() As List(Of Categoria) Implements ICategoriaRepository.ObtenerTodas
            Return _context.Categorias.ToList()
        End Function

        Public Function ObtenerPorId(id As Integer) As Categoria Implements ICategoriaRepository.ObtenerPorId
            Return _context.Categorias.Find(id)
        End Function

        Public Function ObtenerConProductos(id As Integer) As Categoria Implements ICategoriaRepository.ObtenerConProductos
            Return _context.Categorias.Include(Function(c) c.Productos).FirstOrDefault(Function(c) c.Id = id)
        End Function

        Public Function ExistePorNombre(nombre As String) As Boolean Implements ICategoriaRepository.ExistePorNombre
            Return _context.Categorias.Any(Function(c) c.Nombre.ToLower() = nombre.ToLower())
        End Function

        Public Sub Agregar(categoria As Categoria) Implements ICategoriaRepository.Agregar
            _context.Categorias.Add(categoria)
        End Sub

        Public Sub Actualizar(categoria As Categoria) Implements ICategoriaRepository.Actualizar
            _context.Categorias.Update(categoria)
        End Sub

        Public Sub Eliminar(categoria As Categoria) Implements ICategoriaRepository.Eliminar
            _context.Categorias.Remove(categoria)
        End Sub

        Public Function GuardarCambios() As Boolean Implements ICategoriaRepository.GuardarCambios
            Return _context.SaveChanges() > 0
        End Function
    End Class
End Namespace