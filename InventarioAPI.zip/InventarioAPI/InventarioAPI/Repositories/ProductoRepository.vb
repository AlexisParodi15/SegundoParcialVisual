﻿Imports Microsoft.EntityFrameworkCore
Imports InventarioAPI.Data
Imports InventarioAPI.Models

Namespace Repositories
    Public Interface IProductoRepository
        Function ObtenerTodos() As List(Of Producto)
        Function ObtenerPorId(id As Integer) As Producto
        Function ObtenerPorCategoria(categoriaId As Integer) As List(Of Producto)
        Function ExistePorNombre(nombre As String) As Boolean
        Sub Agregar(producto As Producto)
        Sub Actualizar(producto As Producto)
        Sub Eliminar(producto As Producto)
        Function GuardarCambios() As Boolean
    End Interface

    Public Class ProductoRepository
        Implements IProductoRepository

        Private ReadOnly _context As AppDbContext

        Public Sub New(context As AppDbContext)
            _context = context
        End Sub

        Public Function ObtenerTodos() As List(Of Producto) Implements IProductoRepository.ObtenerTodos
            Return _context.Productos.Include(Function(p) p.Categoria).ToList()
        End Function

        Public Function ObtenerPorId(id As Integer) As Producto Implements IProductoRepository.ObtenerPorId
            Return _context.Productos.Include(Function(p) p.Categoria).FirstOrDefault(Function(p) p.Id = id)
        End Function

        Public Function ObtenerPorCategoria(categoriaId As Integer) As List(Of Producto) Implements IProductoRepository.ObtenerPorCategoria
            Return _context.Productos.Include(Function(p) p.Categoria).Where(Function(p) p.CategoriaId = categoriaId).ToList()
        End Function

        Public Function ExistePorNombre(nombre As String) As Boolean Implements IProductoRepository.ExistePorNombre
            Return _context.Productos.Any(Function(p) p.Nombre.ToLower() = nombre.ToLower())
        End Function

        Public Sub Agregar(producto As Producto) Implements IProductoRepository.Agregar
            _context.Productos.Add(producto)
        End Sub

        Public Sub Actualizar(producto As Producto) Implements IProductoRepository.Actualizar
            _context.Productos.Update(producto)
        End Sub

        Public Sub Eliminar(producto As Producto) Implements IProductoRepository.Eliminar
            _context.Productos.Remove(producto)
        End Sub

        Public Function GuardarCambios() As Boolean Implements IProductoRepository.GuardarCambios
            Return _context.SaveChanges() > 0
        End Function
    End Class
End Namespace