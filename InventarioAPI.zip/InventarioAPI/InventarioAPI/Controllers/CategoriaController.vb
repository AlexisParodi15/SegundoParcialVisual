﻿Imports Microsoft.AspNetCore.Mvc
Imports InventarioAPI.Services
Imports InventarioAPI.Models
Imports InventarioAPI.DTOs

Namespace Controllers
    <Route("api/[controller]")>
    <ApiController>
    Public Class CategoriaController
        Inherits ControllerBase

        Private ReadOnly _service As ICategoriaService

        Public Sub New(service As ICategoriaService)
            _service = service
        End Sub

        <HttpGet>
        Public Function GetTodas() As IActionResult
            Dim categorias = _service.ObtenerTodas()
            Dim response = categorias.Select(Function(c) New CategoriaResponseDTO With {
                .Id = c.Id,
                .Nombre = c.Nombre,
                .Descripcion = c.Descripcion
            }).ToList()
            Return Ok(response)
        End Function

        <HttpGet("{id}")>
        Public Function GetPorId(id As Integer) As IActionResult
            Dim categoria = _service.ObtenerPorId(id)
            Dim response = New CategoriaResponseDTO With {
                .Id = categoria.Id,
                .Nombre = categoria.Nombre,
                .Descripcion = categoria.Descripcion
            }
            Return Ok(response)
        End Function

        <HttpPost>
        Public Function Registrar(<FromBody> dto As CategoriaCreateDTO) As IActionResult
            If Not ModelState.IsValid Then
                Return BadRequest(ModelState)
            End If

            Dim categoria As New Categoria With {
                .Nombre = dto.Nombre,
                .Descripcion = dto.Descripcion
            }

            _service.Registrar(categoria)
            Return StatusCode(201, "Categoría registrada exitosamente.")
        End Function

        <HttpPut("{id}")>
        Public Function Modificar(id As Integer, <FromBody> dto As CategoriaUpdateDTO) As IActionResult
            If id <> dto.Id Then
                Return BadRequest("El ID de la ruta no coincide con el ID del cuerpo de la petición.")
            End If

            If Not ModelState.IsValid Then
                Return BadRequest(ModelState)
            End If

            Dim categoria As New Categoria With {
                .Id = dto.Id,
                .Nombre = dto.Nombre,
                .Descripcion = dto.Descripcion
            }

            _service.Modificar(categoria)
            Return Ok("Categoría modificada exitosamente.")
        End Function

        <HttpDelete("{id}")>
        Public Function Eliminar(id As Integer) As IActionResult
            _service.Eliminar(id)
            Return NoContent()
        End Function
    End Class
End Namespace