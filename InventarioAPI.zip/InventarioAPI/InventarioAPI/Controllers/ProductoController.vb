﻿Imports Microsoft.AspNetCore.Mvc
Imports InventarioAPI.Services
Imports InventarioAPI.Models
Imports InventarioAPI.DTOs

Namespace Controllers
    <Route("api/[controller]")>
    <ApiController>
    Public Class ProductoController
        Inherits ControllerBase

        Private ReadOnly _service As IProductoService

        Public Sub New(service As IProductoService)
            _service = service
        End Sub

        <HttpGet>
        Public Function GetTodos() As IActionResult
            Dim productos = _service.ObtenerTodos()
            Dim response = productos.Select(Function(p) New ProductoResponseDTO With {
                .Id = p.Id,
                .Nombre = p.Nombre,
                .Descripcion = p.Descripcion,
                .Precio = p.Precio,
                .Stock = p.Stock,
                .FechaRegistro = p.FechaRegistro,
                .CategoriaId = p.CategoriaId,
                .CategoriaNombre = If(p.Categoria IsNot Nothing, p.Categoria.Nombre, "Sin Categoría") ' Consulta Relacionada[cite: 5]
            }).ToList()
            Return Ok(response)
        End Function

        <HttpGet("{id}")>
        Public Function GetPorId(id As Integer) As IActionResult
            Dim p = _service.ObtenerPorId(id)
            Dim response = New ProductoResponseDTO With {
                .Id = p.Id,
                .Nombre = p.Nombre,
                .Descripcion = p.Descripcion,
                .Precio = p.Precio,
                .Stock = p.Stock,
                .FechaRegistro = p.FechaRegistro,
                .CategoriaId = p.CategoriaId,
                .CategoriaNombre = If(p.Categoria IsNot Nothing, p.Categoria.Nombre, "Sin Categoría")
            }
            Return Ok(response)
        End Function

        <HttpGet("categoria/{categoriaId}")>
        Public Function GetPorCategoria(categoriaId As Integer) As IActionResult
            Dim productos = _service.ObtenerPorCategoria(categoriaId)
            Dim response = productos.Select(Function(p) New ProductoResponseDTO With {
                .Id = p.Id,
                .Nombre = p.Nombre,
                .Descripcion = p.Descripcion,
                .Precio = p.Precio,
                .Stock = p.Stock,
                .FechaRegistro = p.FechaRegistro,
                .CategoriaId = p.CategoriaId,
                .CategoriaNombre = p.Categoria.Nombre
            }).ToList()
            Return Ok(response)
        End Function

        <HttpPost>
        Public Function Registrar(<FromBody> dto As ProductoCreateDTO) As IActionResult
            If Not ModelState.IsValid Then
                Return BadRequest(ModelState)
            End If

            Dim producto As New Producto With {
                .Nombre = dto.Nombre,
                .Descripcion = dto.Descripcion,
                .Precio = dto.Precio,
                .Stock = dto.Stock,
                .CategoriaId = dto.CategoriaId
            }

            _service.Registrar(producto)
            Return StatusCode(201, "Producto registrado exitosamente.")
        End Function

        <HttpPut("{id}")>
        Public Function Modificar(id As Integer, <FromBody> dto As ProductoUpdateDTO) As IActionResult
            If id <> dto.Id Then
                Return BadRequest("El ID de la ruta no coincide.")
            End If

            If Not ModelState.IsValid Then
                Return BadRequest(ModelState)
            End If

            Dim producto As New Producto With {
                .Id = dto.Id,
                .Nombre = dto.Nombre,
                .Descripcion = dto.Descripcion,
                .Precio = dto.Precio,
                .Stock = dto.Stock,
                .CategoriaId = dto.CategoriaId
            }

            _service.Modificar(producto)
            Return Ok("Producto modificado exitosamente.")
        End Function

        <HttpDelete("{id}")>
        Public Function Eliminar(id As Integer) As IActionResult
            _service.Eliminar(id)
            Return NoContent()
        End Function
    End Class
End Namespace