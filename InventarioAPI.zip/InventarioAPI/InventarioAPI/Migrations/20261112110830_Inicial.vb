﻿Imports System
Imports Microsoft.EntityFrameworkCore.Migrations
Imports Microsoft.VisualBasic

Namespace Global.InventarioAPI.Migrations
    ''' <inheritdoc />
    Partial Public Class Inicial
        Inherits Migration

        ''' <inheritdoc />
        Protected Overrides Sub Up(migrationBuilder As MigrationBuilder)
            migrationBuilder.CreateTable(
                name:="Categorias",
                columns:=Function(table) New With {
                    .Id = table.Column(Of Integer)(type:="int", nullable:=False).
                        Annotation("SqlServer:Identity", "1, 1"),
                    .Nombre = table.Column(Of String)(type:="nvarchar(max)", nullable:=True),
                    .Descripcion = table.Column(Of String)(type:="nvarchar(max)", nullable:=True)
                },
                constraints:=Sub(table)
                    table.PrimaryKey("PK_Categorias", Function(x) x.Id)
                End Sub)

            migrationBuilder.CreateTable(
                name:="Productos",
                columns:=Function(table) New With {
                    .Id = table.Column(Of Integer)(type:="int", nullable:=False).
                        Annotation("SqlServer:Identity", "1, 1"),
                    .Nombre = table.Column(Of String)(type:="nvarchar(max)", nullable:=True),
                    .Descripcion = table.Column(Of String)(type:="nvarchar(max)", nullable:=True),
                    .Precio = table.Column(Of Decimal)(type:="decimal(18,2)", nullable:=False),
                    .Stock = table.Column(Of Integer)(type:="int", nullable:=False),
                    .FechaRegistro = table.Column(Of Date)(type:="datetime2", nullable:=False),
                    .CategoriaId = table.Column(Of Integer)(type:="int", nullable:=False)
                },
                constraints:=Sub(table)
                    table.PrimaryKey("PK_Productos", Function(x) x.Id)
                    table.ForeignKey(
                        name:="FK_Productos_Categorias_CategoriaId",
                        column:=Function(x) x.CategoriaId,
                        principalTable:="Categorias",
                        principalColumn:="Id",
                        onDelete:=ReferentialAction.Cascade)
                End Sub)

            migrationBuilder.CreateIndex(
                name:="IX_Productos_CategoriaId",
                table:="Productos",
                column:="CategoriaId")
        End Sub

        ''' <inheritdoc />
        Protected Overrides Sub Down(migrationBuilder As MigrationBuilder)
            migrationBuilder.DropTable(
                name:="Productos")

            migrationBuilder.DropTable(
                name:="Categorias")
        End Sub
    End Class
End Namespace
