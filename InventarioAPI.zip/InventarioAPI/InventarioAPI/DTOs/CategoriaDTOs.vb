﻿Imports System.ComponentModel.DataAnnotations

Namespace DTOs
    Public Class CategoriaCreateDTO
        <Required(ErrorMessage:="El nombre de la categoría es obligatorio")>
        <MaxLength(50, ErrorMessage:="El nombre no puede superar los 50 caracteres")>
        Public Property Nombre As String

        Public Property Descripcion As String
    End Class

    Public Class CategoriaUpdateDTO
        Public Property Id As Integer

        <Required(ErrorMessage:="El nombre de la categoría es obligatorio")>
        <MaxLength(50, ErrorMessage:="El nombre no puede superar los 50 caracteres")>
        Public Property Nombre As String

        Public Property Descripcion As String
    End Class

    Public Class CategoriaResponseDTO
        Public Property Id As Integer
        Public Property Nombre As String
        Public Property Descripcion As String
    End Class
End Namespace