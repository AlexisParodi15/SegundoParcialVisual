﻿Imports System.ComponentModel.DataAnnotations

Namespace DTOs
    Public Class ProductoCreateDTO
        <Required(ErrorMessage:="El nombre del producto es obligatorio")>
        <MaxLength(50, ErrorMessage:="El nombre no puede superar los 50 caracteres")>
        Public Property Nombre As String

        <MaxLength(200, ErrorMessage:="La descripción no puede superar los 200 caracteres")>
        Public Property Descripcion As String

        <Range(0.01, Double.MaxValue, ErrorMessage:="El precio debe ser mayor que cero")>
        Public Property Precio As Decimal

        <Range(0, Integer.MaxValue, ErrorMessage:="El stock no puede ser negativo")>
        Public Property Stock As Integer

        <Required(ErrorMessage:="Debe especificar a qué categoría pertenece el producto")>
        Public Property CategoriaId As Integer
    End Class

    Public Class ProductoUpdateDTO
        Public Property Id As Integer

        <Required(ErrorMessage:="El nombre del producto es obligatorio")>
        <MaxLength(50, ErrorMessage:="El nombre no puede superar los 50 caracteres")>
        Public Property Nombre As String

        <MaxLength(200, ErrorMessage:="La descripción no puede superar los 200 caracteres")>
        Public Property Descripcion As String

        <Range(0.01, Double.MaxValue, ErrorMessage:="El precio debe ser mayor que cero")>
        Public Property Precio As Decimal

        <Range(0, Integer.MaxValue, ErrorMessage:="El stock no puede ser negativo")>
        Public Property Stock As Integer

        <Required(ErrorMessage:="Debe especificar a qué categoría pertenece el producto")>
        Public Property CategoriaId As Integer
    End Class

    Public Class ProductoResponseDTO
        Public Property Id As Integer
        Public Property Nombre As String
        Public Property Descripcion As String
        Public Property Precio As Decimal
        Public Property Stock As Integer
        Public Property FechaRegistro As DateTime
        Public Property CategoriaId As Integer
        Public Property CategoriaNombre As String
    End Class
End Namespace